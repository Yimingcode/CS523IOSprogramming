//
//  ViewController.swift
//  Calculator
//
//  Created by 徐一鸣 on 2/3/19.
//  Copyright © 2019 SupYiming. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    var firstNumber = ""
    var secondNumber = ""
    var operand=""
    var result:String=""
    
    @IBOutlet weak var My_Label: UILabel!
    
    @IBOutlet weak var My_TextField: UITextField!
    
    
    @IBAction func My_Clear(_ sender: Any) {
        My_TextField.text=""
        result=""
        firstNumber = ""
        secondNumber = ""
        operand=""
        result=""
    }
    
    @IBAction func MyOne(_ sender: Any) {
        if result == ""{
            My_TextField.text = "1"
            result = "1"
        } else {
            result = result + "1"
            My_TextField.text = result
        }
    }
    
    @IBAction func MyTwo(_ sender: Any) {
        if result == ""{
            My_TextField.text = "2"
            result = "2"
        } else {
            result = result + "2"
            My_TextField.text = result
        }
    }
    
    @IBAction func MyThree(_ sender: Any) {
        if result == ""{
            My_TextField.text = "3"
            result = "3"
        } else {
            result = result + "3"
            My_TextField.text = result
        }
    }
    
    
    @IBAction func MyFour(_ sender: Any) {
        if result == "" {
            My_TextField.text = "4"
            result = "4"
        } else{
            result = result + "4"
            My_TextField.text = result
        }
    }
    
    @IBAction func MyFive(_ sender: Any) {
        if result == "" {
            My_TextField.text = "5"
            result = "5"
        } else{
            result = result + "5"
            My_TextField.text = result
        }
    }
    
    @IBAction func MySix(_ sender: Any) {
        if result == "" {
            My_TextField.text = "6"
            result = "6"
        } else{
            result = result + "6"
            My_TextField.text = result
        }
    }
    
    
    @IBAction func MySeven(_ sender: Any) {
        if result == "" {
            My_TextField.text = "7"
            result = "7"
        } else{
            result = result + "7"
            My_TextField.text = result
        }
    }
    
   
    @IBAction func MyEight(_ sender: Any) {
        if result == "" {
            My_TextField.text = "8"
            result = "8"
        } else{
            result = result + "8"
            My_TextField.text = result
        }
    }
    
    @IBAction func MyNine(_ sender: Any) {
        if result == "" {
            My_TextField.text = "9"
            result = "9"
        } else{
            result = result + "9"
            My_TextField.text = result
        }
    }
    
    @IBAction func MyZero(_ sender: Any) {
        if result == "" {
            My_TextField.text = "0"
            result = "0"
        } else{
            result = result + "0"
            My_TextField.text = result
        }
    }
    
    @IBAction func MyAdd(_ sender: Any) {
        firstNumber = result
        My_TextField.text = result + "+"
        operand = "+"
        result = ""
    }
    
    @IBAction func MySubstract(_ sender: Any) {
        firstNumber = result
        My_TextField.text = result + "-"
        operand = "-"
        result = ""
    }
    
    @IBAction func MyMultiply(_ sender: Any) {
        firstNumber = result
        My_TextField.text = result + "*"
        operand = "*"
        result = ""
    }
    
    
    @IBAction func MyDivide(_ sender: Any) {
        firstNumber = result
        My_TextField.text = result + "/"
        operand = "/"
        result = ""
    }
    
    @IBAction func MyEqual(_ sender: Any) {
        let firstNumberInt: Double = Double(firstNumber)!
        let secondNumberInt: Double = Double(result)!
        
        var finalResult:Double = 0
        if operand == "+" {
            finalResult = firstNumberInt + secondNumberInt
        } else if operand == "-" {
            finalResult = firstNumberInt - secondNumberInt
        } else if operand == "*" {
            finalResult = firstNumberInt * secondNumberInt
        } else if operand == "/" {
            finalResult = firstNumberInt / secondNumberInt
        }
        
        My_TextField.text = ""
        My_TextField.text = String(finalResult)
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

}

